<?php

namespace Illuminate\Collections;

use RuntimeException;

class MultipleItemsFoundException extends RuntimeException
{
}
